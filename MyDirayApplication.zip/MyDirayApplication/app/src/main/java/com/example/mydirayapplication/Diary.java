package com.example.mydirayapplication;

public class Diary {
    public String title;
    public String author;
    public String body;
    public String time;
    public int id;

    public Diary() {
    }//无参构造器

    public Diary(String title, String author, String body, String time) {
        this.title = title;
        this.author = author;
        this.body = body;
        this.time = time;
    }

}
