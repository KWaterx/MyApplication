package com.example.mydirayapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;


public class MainActivity extends AppCompatActivity {
    private MyDatabaseHelper dbHelper;
    private Intent intent;
    private Bundle bundle;
    String title0;
    String author0;
    String body0;
    String time0;
    int id0;
    String author_;
    private boolean isExit=false;
    //    private boolean isExit=false;
//    private Timer timer;
//    @Override
//    public boolean onKeyDown(int keyCode, KeyEvent event) {
//        //点击返回键调用方法
//        if(keyCode==KeyEvent.KEYCODE_BACK){
//            exit();
//        }
//        return false;
//    }
//
//    private void exit() {
//        if (isExit==false){
//            isExit=true;
//            Toast.makeText(this,"再按一次退出",Toast.LENGTH_SHORT).show();
//            timer=new Timer();
//            timer.schedule(new TimerTask() {
//                @Override
//                public void run() {
//                    isExit=false;
//                }
//            },2000);
//        }else {
//            //2000ms内按第二次则退出
//            finish();
//            System.exit(0);
//        }
//
//    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        //点击返回键调用方法
        if(keyCode==KeyEvent.KEYCODE_BACK){
            setResult(2, (new Intent(MainActivity.this, ActivityOfList.class)));
            Intent intent = new Intent(MainActivity.this, ActivityOfList.class);
            startActivity(intent);
            finish();
            overridePendingTransition(R.anim.in_from_left, R.anim.out_to_right);//设置Activity左进右出动画效果
// TODO Auto-generated method stub
        }
        return false;
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initData();
        dbHelper = new MyDatabaseHelper(this, "MyDiary.db", null, 1);
//        Button createDatabase = (Button) findViewById(R.id.create_database);
        Button updData = (Button) findViewById(R.id.upd_data);
        Button delete = (Button) findViewById(R.id.delete_data);
        EditText title = (EditText) findViewById(R.id.et_title);
        EditText time = (EditText) findViewById(R.id.et_time);
        EditText body = (EditText) findViewById(R.id.et_body);
        EditText author = (EditText) findViewById(R.id.et_author);

        title.setText(title0);
        author.setText(author0);
        body.setText(body0);
        time.setText(time0);
        String s = time.getText().toString();
        String[] aa = new String[]{s};


//        createDatabase.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                dbHelper.getWritableDatabase();
//            }
//        });


        updData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!author.getText().toString().equals("")) {
                    SharedPreferences.Editor editor = getSharedPreferences("data", MODE_PRIVATE).edit();
                    System.out.println("@#@#@#@#@#%%%%%%" + author.getText().toString());
                    editor.putString("author", author.getText().toString());
                    editor.commit();
                }//利用SharedPreferences来获取默认作者名
                String tit;
                tit = title.getText().toString();
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put("title", tit);
                values.put("body", body.getText().toString());
                values.put("author", author.getText().toString());

                if (tit.equals("")) {
                    Toast.makeText(MainActivity.this, "请输入标题", Toast.LENGTH_SHORT).show();
                    return;
                }//必须输入标题
                if (!tit.equals("")) {
                    SimpleDateFormat formatter = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss");
                    Date curDate = new Date(System.currentTimeMillis());//获取当前时间
                    String str = formatter.format(curDate);
                    values.put("time", str);
                }//更新时间

                if (db.update("Diary", values, "time=?", aa) == 1) {
                    Toast.makeText(MainActivity.this, "保存成功", Toast.LENGTH_SHORT).show();
                } else {
                    restoreData();//获取名字
                    values.put("author", author_);
                    db.insert("Diary", null, values);
                    Toast.makeText(MainActivity.this, "新建成功", Toast.LENGTH_SHORT).show();
                }
//                setResult(2, (new Intent(MainActivity.this, ActivityOfList.class)));
                Intent intent = new Intent(MainActivity.this, ActivityOfList.class);
                startActivity(intent);
                values.clear();
                finish();
                overridePendingTransition(R.anim.in_from_left, R.anim.out_to_right);//设置Activity左进右出动画效果
// TODO Auto-generated method stub
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                if (db.delete("Diary", "time=?", aa) == 1) {
                    Toast.makeText(MainActivity.this, "删除成功", Toast.LENGTH_LONG).show();
                }
//                setResult(2, (new Intent(MainActivity.this, ActivityOfList.class)));
                Intent intent = new Intent(MainActivity.this, ActivityOfList.class);
                startActivity(intent);
                finish();
                overridePendingTransition(R.anim.in_from_left, R.anim.out_to_right);//设置Activity左进右出动画效果
// TODO Auto-generated method stub
            }
        });


    }

    private void restoreData() {
        SharedPreferences prefs = getSharedPreferences("data", MODE_PRIVATE);
        author_ = prefs.getString("author", "");
    }

    private void initData() {
        intent = this.getIntent();
        bundle = intent.getExtras();
        if (bundle == null) {
            title0 = "";
            author0 = "";
            body0 = "";
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss");
            Date curDate = new Date(System.currentTimeMillis());//获取当前时间
            String str = formatter.format(curDate);
            time0 = str;
        } else {
            title0 = bundle.getString("title");
            author0 = bundle.getString("author");
            body0 = bundle.getString("body");
            time0 = bundle.getString("time");
            id0 = bundle.getInt("id");
            System.out.println("@#@#@#@#@");
            System.out.println("标题：" + title0);
            System.out.println("作者：" + author0);
            System.out.println("正文：" + body0);
            System.out.println("时间：" + time0);
            System.out.println("编号：" + id0);
            System.out.println("@#@#@#@#@");
        }

    }
}