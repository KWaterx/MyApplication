package com.example.mydirayapplication;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;


public class ActivityOfList extends AppCompatActivity {
    private MyDatabaseHelper dbHelper;
    private List<Diary> diaryList=new ArrayList<Diary>();
    public static int GET_CODE=2;

    private boolean isExit=false;
    private Timer timer;


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        //点击返回键调用方法
        if(keyCode==KeyEvent.KEYCODE_BACK){
            exit();
        }
        return false;
    }

    private void exit() {
        if (isExit==false){
            isExit=true;
            Toast.makeText(this,"再按一次退出",Toast.LENGTH_SHORT).show();
            timer=new Timer();
            timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    isExit=false;
                }
            },2000);
        }else {
            //2000ms内按第二次则退出
            finish();
            System.exit(0);
        }

    }

//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        if (resultCode == GET_CODE) {
//            //GET_CODE是自定义的页面跳转识别码
//            Intent intent = new Intent(this, ActivityOfList.class);
//            startActivity(intent);
//        }
//    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

//        dbHelper = new MyDatabaseHelper(this, "MyDiary.db", null, 1);
        setContentView(R.layout.list_diray);
        initDiary();//初始化
        DiaryAdapter adapter=new DiaryAdapter(ActivityOfList.this,
                R.layout.diray_item,diaryList);
        ListView listView=(ListView) findViewById(R.id.list_view);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                Diary diary = diaryList.get(position);
//                Toast.makeText(ActivityOfList.this, diary.body,
//                        Toast.LENGTH_SHORT).show();
                Intent intent=new Intent();
                intent.setClass(ActivityOfList.this, MainActivity.class);
                Bundle bundle=new Bundle();
                bundle.putString("title",diary.title);
                bundle.putString("author",diary.author);
                bundle.putString("body",diary.body);
                bundle.putString("time",diary.time);
                bundle.putInt("id",diary.id);
                intent.putExtras(bundle);
                startActivityForResult(intent,0);
                finish();
            }
        });
        Button addData = (Button) findViewById(R.id.add_data);
        addData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(ActivityOfList.this, "新建文本", Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(ActivityOfList.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });



    }

    private void initDiary() {
        dbHelper = new MyDatabaseHelper(this, "MyDiary.db", null, 1);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        Cursor cursor = db.query("Diary", null, null, null, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String title = cursor.getString(cursor.getColumnIndex("title"));
                @SuppressLint("Range") String author = cursor.getString(cursor.getColumnIndex("author"));
                @SuppressLint("Range") String body = cursor.getString(cursor.getColumnIndex("body"));
                @SuppressLint("Range") String time = cursor.getString(cursor.getColumnIndex("time"));

                diaryList.add(new Diary(title,author,body,time));

            } while (cursor.moveToNext());
        }
        cursor.close();



    }






}
//        ArrayList<String> data=new ArrayList<>() ;
//        data.add("Hello");
//        data.add("word");
//        setContentView(R.layout.list_diray);
//        dbHelper = new MyDatabaseHelper(this, "MyDiary.db", null, 1);
//        SQLiteDatabase db = dbHelper.getWritableDatabase();
//        Cursor cursor = db.query("Diary", null, null, null, null, null, null);
//        if (cursor.moveToFirst()) {
//            do {
//                @SuppressLint("Range") String title = cursor.getString(cursor.getColumnIndex("title"));
//                data.add(title);
//            } while (cursor.moveToNext());
//        }
//        cursor.close();
//
//        ArrayAdapter<String> adapter=new ArrayAdapter<String>(ActivityOfList.this,
//                android.R.layout.simple_list_item_1,data);
//        ListView listView=(ListView)findViewById(R.id.list_title);
//        listView.setAdapter(adapter);
//    }
//}
