package com.example.mydirayapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class DiaryAdapter extends ArrayAdapter<Diary> {
    private int resourceId;
    public DiaryAdapter(Context context, int textViewResourceId,
                        List<Diary> objects) {
        super(context, textViewResourceId, objects);
        resourceId = textViewResourceId;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Diary diary = getItem(position);
        View view = LayoutInflater.from(getContext()).inflate(resourceId, null);

        TextView diaryTitle = (TextView) view.findViewById(R.id.diary_title);
        diaryTitle.setText(diary.title);

//        TextView diaryAuthor = (TextView) view.findViewById(R.id.diary_author);
//        diaryAuthor.setText(diary.author);
//
//        TextView diaryBody = (TextView) view.findViewById(R.id.diary_body);
//        diaryBody.setText(diary.body);

        TextView diaryTime = (TextView) view.findViewById(R.id.diary_time);
        String time=diary.time;
        time=time.substring(0,11);
        diaryTime.setText(time);
        return view;
    }

}
