package com.example.myapplicationweatherreport;

import org.litepal.crud.DataSupport;

public class Like extends DataSupport {
    String cityName;
    String cityID;
   public Like(){}
   public Like(String cityName,String cityID){
       this.cityName=cityName;
       this.cityID=cityID;
   }
}
