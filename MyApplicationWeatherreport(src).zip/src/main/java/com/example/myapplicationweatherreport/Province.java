package com.example.myapplicationweatherreport;

import org.litepal.crud.DataSupport;

public class Province extends DataSupport {
    String name;
    String ProvinceId;
    public Province(){}
    public Province(String name,String ProvinceId){
        this.name=name;
        this.ProvinceId=ProvinceId;
    }
}
