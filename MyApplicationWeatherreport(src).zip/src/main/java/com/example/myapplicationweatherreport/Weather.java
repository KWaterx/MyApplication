package com.example.myapplicationweatherreport;

import org.litepal.crud.DataSupport;

public class Weather extends DataSupport {
    public String temperature;
    public String high;
    public String low;
    public String time;
    public String name;
    public String humidity;
    public String PM;
    public Weather(){}
    public Weather(String name,String temperature ,String high,String low,String time,String humidity,String PM){
        this.name=name;
        this.temperature=temperature;
        this.high=high;
        this.low=low;
        this.time=time;
        this.humidity=humidity;
        this.PM=PM;
    }

}
