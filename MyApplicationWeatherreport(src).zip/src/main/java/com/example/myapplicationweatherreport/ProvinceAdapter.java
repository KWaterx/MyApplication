package com.example.myapplicationweatherreport;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class ProvinceAdapter extends ArrayAdapter<Province> {
    private int resourceId;
    public ProvinceAdapter(Context context, int textViewResourceId,
                           List<Province> objects) {
        super(context, textViewResourceId, objects);
        resourceId = textViewResourceId;
    }


    @Override
    public View getView(int position,  View convertView,  ViewGroup parent) {
       Province province=getItem(position);
       View view= LayoutInflater.from(getContext()).inflate(resourceId,null);

        TextView provinceName=(TextView) view.findViewById(R.id.name);
        provinceName.setText(province.name);

        return view;
    }
}
