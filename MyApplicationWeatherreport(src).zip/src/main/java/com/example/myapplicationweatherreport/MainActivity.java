package com.example.myapplicationweatherreport;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.litepal.LitePal;
import org.litepal.crud.DataSupport;

import java.io.IOException;
import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


// 创建ListView控件
//使用OkHttp把地址中的Json字符串请求回来
//将Json字符串解析成省份数据类型和天气数据
//在Adapter中的getView方法中 将省份中的省份名 显示在控件

public class MainActivity extends AppCompatActivity {
    private Intent intent;
    private Bundle bundle;
    Weather weather;
    String name0;
    String cityID;
    String url;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LitePal.getDatabase();
        setContentView(R.layout.activity_main);
        initData();
        String JsonData = null;
        List<Weather> list = DataSupport.where("name=?", name0).find(Weather.class);

        if (!list.isEmpty()) {
            weather = list.get(0);
            Toast.makeText(MainActivity.this, "历史数据", Toast.LENGTH_SHORT).show();
        } else {
            try {
                JsonData = sendRequestWithOKHttp();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            //测试
            System.out.println("**" + JsonData);
            weather = parseJSONWithJSONObject(JsonData);

        }
        TextView name = (TextView) findViewById(R.id.et_name);
        TextView temperature = (TextView) findViewById(R.id.et_temperature);
        TextView time = (TextView) findViewById(R.id.et_time);
        TextView humidity = (TextView) findViewById(R.id.et_humidity);
        TextView PM = (TextView) findViewById(R.id.et_PM);
        Button updata = (Button) findViewById(R.id.upd_data);
        Button Like = (Button) findViewById(R.id.sav_data);

        name.setText(name0);
        temperature.setText(weather.temperature + "℃");
        time.setText(weather.time);
        humidity.setText(weather.humidity);
        PM.setText(weather.PM);


        updata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DataSupport.deleteAll(Weather.class, "name=?", name0);
                Intent intent = new Intent();
                intent.setClass(MainActivity.this, MainActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("CityId", cityID);
                bundle.putString("CityName", name0);
                intent.putExtras(bundle);
                startActivityForResult(intent, 0);
                finish();
                bundle.clear();
                Toast.makeText(MainActivity.this, "刷新成功", Toast.LENGTH_SHORT).show();
            }
        });

        Like.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Like like = new Like(name0, cityID);
                List<Like> list = DataSupport.where("cityName=?", name0).find(Like.class);
                if (list.isEmpty()) {
                    like.save();
                    Toast.makeText(MainActivity.this, "收藏成功", Toast.LENGTH_SHORT).show();
                } else {
                    like.deleteAll(Like.class, "cityName=?", name0);
                    Toast.makeText(MainActivity.this, "已取消收藏", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }


    private void initData() {


        intent = this.getIntent();
        bundle = intent.getExtras();
        cityID = bundle.getString("CityId");
        url = "http://t.weather.itboy.net/api/weather/city/" + cityID;
        name0 = bundle.getString("CityName");
        System.out.println(" ");
        System.out.println("*#*#*#*#*");
        System.out.println("城市：" + name0);
        System.out.println("城市ID：" + cityID);
        System.out.println("*#*#*#*#*");
    }


    private String sendRequestWithOKHttp() throws InterruptedException {
        final String[] responseData = new String[1];

        Thread get = new Thread(new Runnable() {
            @Override
            public void run() {
                OkHttpClient client = new OkHttpClient();//创建OkHttpClient的实例
                Request request = new Request.Builder().url(url).build();
                try {
                    Response response = client.newCall(request).execute();//调用execute（）方法，请求并获取服务器返回的数据
                    responseData[0] = response.body().string();


                } catch (IOException e) {
                    e.printStackTrace();

                }
            }
        });
        get.start();
        get.join();
        System.out.println("&&" + responseData[0]);
        return responseData[0];
    }

    private Weather parseJSONWithJSONObject(String jsonData) {
        Weather weather0 = null;
        try {
            String time = ChangeJson.getString(jsonData, "time");
            String Data = ChangeJson.getString(jsonData, "data");
            String humidity = ChangeJson.getString(Data, "shidu");
            String PM = ChangeJson.getString(Data, "pm25");
            String temperature = ChangeJson.getString(Data, "wendu");
            String forecast = ChangeJson.getString(Data, "forecast");
            String high = null;
            String low = null;
            JSONArray jsonArray = new JSONArray(forecast);


            for (int i = 0; i < 1; i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                high = jsonObject.getString("high");
                low = jsonObject.getString("low");
            }

            //测试
            System.out.println(" ");
            System.out.println("*#*#*#*#*");
            System.out.println("温度：" + temperature);
            System.out.println("时间：" + time);
            System.out.println("湿度：" + humidity);
            System.out.println("PM2.5：" + PM);
            System.out.println(high);
            System.out.println(low);
            System.out.println("*#*#*#*#*");
            System.out.println(" ");

            weather0 = new Weather(name0, temperature, high, low, time, humidity, PM);
            weather0.save();

            return weather0;
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }

    }

    public static class ChangeJson {
        public static String getString(String data, String result) {
            JSONObject jsonObject = null;
            try {
                jsonObject = new JSONObject(data);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return jsonObject.optString(result, "noFind");
        }
    }

}