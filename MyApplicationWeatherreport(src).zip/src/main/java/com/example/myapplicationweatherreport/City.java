package com.example.myapplicationweatherreport;

import org.litepal.crud.DataSupport;

public class City extends DataSupport {
    String name;
    String P_ID;
    String  cityId;
    public City(){}
    public City(String name,String P_ID,String cityId ){
        this.name=name;
        this.P_ID=P_ID;
        this.cityId=cityId;
    }
}
