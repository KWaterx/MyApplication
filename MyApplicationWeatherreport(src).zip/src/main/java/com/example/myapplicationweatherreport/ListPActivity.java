package com.example.myapplicationweatherreport;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.AssetManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.litepal.crud.DataSupport;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class ListPActivity extends AppCompatActivity {
    private List<Province> provinceList = new ArrayList<Province>();
    private List<Like> likeList = new ArrayList<Like>();
    private MyDatabaseHelper dbHelper;
    LikeAdapter adapter_2;
    ListView listView_2;

    @Override
    protected void onResume() {
        super.onResume();
        initData();
        adapter_2=new LikeAdapter(ListPActivity.this, R.layout.item_2, likeList);
        listView_2= (ListView) findViewById(R.id.list_view_2);
        listView_2.setAdapter(adapter_2);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_p);
        initData();//初始化省份和收藏

        ProvinceAdapter adapter = new ProvinceAdapter(ListPActivity.this, R.layout.item, provinceList);
        ListView listView = (ListView) findViewById(R.id.list_view);
        listView.setAdapter(adapter);

        adapter_2=new LikeAdapter(ListPActivity.this, R.layout.item_2, likeList);
        listView_2= (ListView) findViewById(R.id.list_view_2);
        listView_2.setAdapter(adapter_2);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                Province province = provinceList.get(position);
                Intent intent = new Intent();
                intent.setClass(ListPActivity.this, ListCActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("ProvinceId", province.ProvinceId);
                intent.putExtras(bundle);
                startActivityForResult(intent, 0);

            }
        });

        listView_2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                Like like = likeList.get(position);
                Intent intent = new Intent();
                intent.setClass(ListPActivity.this, MainActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("CityName", like.cityName);
                bundle.putString("CityId", like.cityID);
                intent.putExtras(bundle);
                startActivityForResult(intent, 0);

            }
        });

        Button search = (Button) findViewById(R.id.search);
//        Button upUp = (Button) findViewById(R.id.btnApp);
        EditText name = (EditText) findViewById(R.id.et_Cityname);


        search.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {
                String city_name = name.getText().toString();
                Log.d("tag", city_name);
                List<City> Lcity= DataSupport.where("name=?",city_name).find(City.class);
                if(Lcity.size()<=0){
                    Toast.makeText(ListPActivity.this,"无该城市",Toast.LENGTH_SHORT).show();
                    name.setText("");
                }else{
                Intent intent = new Intent();
                intent.setClass(ListPActivity.this, MainActivity.class);
                Bundle bundle1 = new Bundle();
                bundle1.putString("CityId", Lcity.get(0).cityId);
                bundle1.putString("CityName", city_name);
                intent.putExtras(bundle1);
                startActivityForResult(intent, 0);
                name.setText("");
                }
            }
        });

//        upUp.setOnClickListener(new View.OnClickListener() {
//
//
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent();
//                intent.setClass(ListPActivity.this, ListPActivity.class);
//                startActivityForResult(intent, 0);
//                finish();
//            }
//        });

    }

    private void initData() {
        provinceList = DataSupport.findAll(Province.class);
        likeList=DataSupport.findAll(Like.class);
        if (provinceList.size() <= 0) {
            String result = getJson("city.json");

            try {
                JSONArray json = new JSONArray(result);
                for (int i = 0; i < json.length(); i++) {
                    JSONObject jb = json.getJSONObject(i);
                    if (jb.getString("pid").equals("0")) {//以pid=0判断省份
                        Province province = new Province(jb.getString("city_name"), jb.getString("id"));
                        province.save();
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
//        dbHelper = new MyDatabaseHelper(this, "MyDatabase.db", null, 1);
//        SQLiteDatabase db = dbHelper.getWritableDatabase();
//        Cursor cursor = db.query("Province", null, null, null, null, null, null);
//
//        if (cursor.moveToFirst()) {
//            do {
//                @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex("name"));
//                @SuppressLint("Range") String ID = cursor.getString(cursor.getColumnIndex("id"));
//
//                provinceList.add(new Province(name,ID));
//
//            } while (cursor.moveToNext());
//        }
//        cursor.close();
        }
    }

    public String getJson(String fileName) {
        StringBuilder stringBuilder = new StringBuilder();
        try {
            AssetManager assetManager = ListPActivity.this.getAssets();
            BufferedReader bf = new BufferedReader(new InputStreamReader(assetManager.open(fileName)));
            String line;
            while ((line = bf.readLine()) != null) {
                stringBuilder.append(line);
                Log.d("AAA", line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return stringBuilder.toString();
    }
}
