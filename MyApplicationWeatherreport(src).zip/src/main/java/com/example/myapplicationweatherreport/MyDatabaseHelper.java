package com.example.myapplicationweatherreport;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class MyDatabaseHelper  extends SQLiteOpenHelper {
    public static final String CREATE_Province = "create table Province ("
            + "id text primary key , name text " + " )";
    //升级数据库：

    public static final String CREATE_City = "create table City ("
            + "id text primary key , pid text ,name text " + " )";
    //升级数据库：

    private Context mContext;

    public MyDatabaseHelper(Context context, String name, SQLiteDatabase.CursorFactory
            factory, int version) {
        super(context, name, factory, version);
        mContext = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(CREATE_Province);
        db.execSQL(CREATE_City);

        initDatabase(db); //测试  省份与市初始化


        Toast.makeText(mContext, "数据库创建成功", Toast.LENGTH_SHORT).show();
    }

    private void initDatabase(SQLiteDatabase db) {
        ContentValues values = new ContentValues();
        //Province初始化
        values.put("id","1");
        values.put("name","四川");
        db.insert("Province",null,values);
        values.clear();

        values.put("id","2");
        values.put("name","广东");
        db.insert("Province",null,values);
        values.clear();

        values.put("id","3");
        values.put("name","福建");
        db.insert("Province",null,values);
        values.clear();

        //city 初始化
        values.put("id","11");
        values.put("pid","1");
        values.put("name","成都");
        db.insert("City",null,values);
        values.clear();

        values.put("id","12");
        values.put("pid","1");
        values.put("name","泸州");
        db.insert("City",null,values);
        values.clear();

        values.put("id","21");
        values.put("pid","2");
        values.put("name","广州");
        db.insert("City",null,values);
        values.clear();

        values.put("id","31");
        values.put("pid","3");
        values.put("name","福州");
        db.insert("City",null,values);
        values.clear();
    }

    //升级数据库
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}




