package com.example.myapplicationweatherreport;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.AssetManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.litepal.LitePal;
import org.litepal.crud.DataSupport;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class ListCActivity extends AppCompatActivity {
    private Intent intent;
    private Bundle bundle;
    private MyDatabaseHelper dbHelper;
    private List<City> cityList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.list_c);
        initData();//初始化市
        CityAdapter adapter = new CityAdapter(ListCActivity.this, R.layout.item, cityList);
        ListView listView = (ListView) findViewById(R.id.list_view);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                City city = cityList.get(position);
                Intent intent = new Intent();
                intent.setClass(ListCActivity.this, MainActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("CityId", city.cityId);
                bundle.putString("CityName", city.name);
                intent.putExtras(bundle);
                startActivityForResult(intent, 0);

            }
        });


        Button search = (Button) findViewById(R.id.search);
        EditText name = (EditText) findViewById(R.id.et_Cityname);


        search.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {
                String city_name = name.getText().toString();
                Log.d("tag", city_name);
                List<City> Lcity= DataSupport.where("name=?",city_name).find(City.class);
                if(Lcity.size()<=0){
                    Toast.makeText(ListCActivity.this,"无该城市",Toast.LENGTH_SHORT).show();
                    name.setText("");
                }else{
                    Intent intent = new Intent();
                    intent.setClass(ListCActivity.this, MainActivity.class);
                    Bundle bundle1 = new Bundle();
                    bundle1.putString("CityId", Lcity.get(0).cityId);
                    bundle1.putString("CityName", city_name);
                    intent.putExtras(bundle1);
                    startActivityForResult(intent, 0);
                    name.setText("");
                }
            }
        });


    }

    private void initData() {
        intent = this.getIntent();
        bundle = intent.getExtras();
        String ProvinceID = bundle.getString("ProvinceId");

        System.out.println(" ");
        System.out.println("#~~~~~~~~~~~~~#");
        System.out.println("省份ID：" + ProvinceID);
        System.out.println("#~~~~~~~~~~~~~#");


//        dbHelper = new MyDatabaseHelper(this, "MyDatabase.db", null, 1);
//        SQLiteDatabase db = dbHelper.getWritableDatabase();
//        Cursor cursor = db.query("City", null, null, null, null, null, null);

        //遍历 Database 里面的 city 表，并依照省份ID来筛选城市
//        if (cursor.moveToFirst()) {
//            do {
//
//                @SuppressLint("Range") String PID = cursor.getString(cursor.getColumnIndex("pid"));
//
//
//                if (PID.equals(ProvinceID)) {
//                    @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex("name"));
//                    @SuppressLint("Range") String ID = cursor.getString(cursor.getColumnIndex("id"));
//                    cityList.add(new City(name, PID, ID));
//                    System.out.println(" ");
//                    System.out.println("*————————————————*");
//                    System.out.println("城市：" + name);
//                    System.out.println("省份ID：" + PID);
//                    System.out.println("城市ID：" + ID);
//                    System.out.println("*————————————————*");
//                } else continue;
//
//            } while (cursor.moveToNext());
//        }
//        cursor.close();
        List<City> listcity = DataSupport.findAll(City.class);
        if (listcity.size() > 0) {
            for (City city : listcity) {
                if (ProvinceID.equals(city.P_ID)) {
                    cityList.add(city);
                }
            }
        } else {
            String result = getJson("city.json");

            try {
                JSONArray json = new JSONArray(result);
                for (int i = 0; i < json.length(); i++) {
                    JSONObject jb = json.getJSONObject(i);
                    if (!jb.getString("pid").equals("0")) {//添加城市
                        City city = new City(jb.getString("city_name"), jb.getString("pid"), jb.getString("city_code"));
                        city.save();
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    public String getJson(String fileName) {
        StringBuilder stringBuilder = new StringBuilder();
        try {
            AssetManager assetManager = ListCActivity.this.getAssets();
            BufferedReader bf = new BufferedReader(new InputStreamReader(assetManager.open(fileName)));
            String line;
            while ((line = bf.readLine()) != null) {
                stringBuilder.append(line);
                Log.d("AAA", line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return stringBuilder.toString();
    }

}



