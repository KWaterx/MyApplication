package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btn_0, btn_1, btn_2, btn_3, btn_4, btn_5, btn_6, btn_7, btn_8, btn_9, btn_pt;
    Button btn_mul, btn_div, btn_add, btn_sub, btn_gh;
    Button btn_clr, btn_eq, btn_cg, btn_del;
    EditText et_input;
    sq sq_1 = new sq();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn_0 = (Button) findViewById(R.id.btn_0);
        btn_1 = (Button) findViewById(R.id.btn_1);
        btn_2 = (Button) findViewById(R.id.btn_2);
        btn_3 = (Button) findViewById(R.id.btn_3);
        btn_4 = (Button) findViewById(R.id.btn_4);
        btn_5 = (Button) findViewById(R.id.btn_5);
        btn_6 = (Button) findViewById(R.id.btn_6);
        btn_7 = (Button) findViewById(R.id.btn_7);
        btn_8 = (Button) findViewById(R.id.btn_8);
        btn_9 = (Button) findViewById(R.id.btn_9);
        btn_pt = (Button) findViewById(R.id.btn_pt);
        btn_add = (Button) findViewById(R.id.btn_add);
        btn_sub = (Button) findViewById(R.id.btn_sub);
        btn_mul = (Button) findViewById(R.id.btn_mul);
        btn_div = (Button) findViewById(R.id.btn_div);
        btn_clr = (Button) findViewById(R.id.btn_clr);
        btn_del = (Button) findViewById(R.id.btn_del);
        btn_eq = (Button) findViewById(R.id.btn_eq);
        btn_gh = (Button) findViewById(R.id.btn_gh);
        btn_cg = (Button) findViewById(R.id.btn_cg);
        et_input = (EditText) findViewById(R.id.et_input);


        btn_0.setOnClickListener(this);
        btn_1.setOnClickListener(this);
        btn_2.setOnClickListener(this);
        btn_3.setOnClickListener(this);
        btn_4.setOnClickListener(this);
        btn_5.setOnClickListener(this);
        btn_6.setOnClickListener(this);
        btn_7.setOnClickListener(this);
        btn_8.setOnClickListener(this);
        btn_9.setOnClickListener(this);
        btn_pt.setOnClickListener(this);
        btn_add.setOnClickListener(this);
        btn_sub.setOnClickListener(this);
        btn_mul.setOnClickListener(this);
        btn_div.setOnClickListener(this);
        btn_clr.setOnClickListener(this);
        btn_del.setOnClickListener(this);
        btn_eq.setOnClickListener(this);
        btn_gh.setOnClickListener(this);
        btn_cg.setOnClickListener(this);
    }

    boolean er_flag = false;//"错误"标志符 false表示无错误
    boolean pt_flag = true;//"小数点"标识符 true表示可以输入

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View v) {

        if (er_flag) {
            et_input.setText("");
            er_flag = false;
            pt_flag = true;
        }//如果错误，则在下一次点击时文本框置空
        String str = et_input.getText().toString();//获得文本框内容
        switch (v.getId()) {
            case R.id.btn_pt:
                if (((Button) v).getText().equals(".")) {//关于小数点的输入判断
                    if (pt_flag) {
                        pt_flag = false;
                        if (str.endsWith(".")) {
                            break;
                        } else if (str.equals("") || str == null || str.endsWith("+") || str.endsWith("-") || str.endsWith("×") || str.endsWith("÷")) {
                            et_input.setText(str + "0" + ((Button) v).getText());
                            break;//若单独输入小数点则自动添加‘0’在前
                        } else {
                            et_input.setText(str + ((Button) v).getText());
                            break;
                        }
                    } else break;
                }
            case R.id.btn_0:
            case R.id.btn_1:
            case R.id.btn_2:
            case R.id.btn_3:
            case R.id.btn_4:
            case R.id.btn_5:
            case R.id.btn_6:
            case R.id.btn_7:
            case R.id.btn_8:
            case R.id.btn_9:
            case R.id.btn_add:
            case R.id.btn_sub:
            case R.id.btn_mul:
            case R.id.btn_div:
//                if(str.equals(null)||str.equals(""))
//                System.out.println("null");

//                 else if (str.equals("") && (((Button) v).getText().equals("×") || ((Button) v).getText().equals("÷"))) {
//                    et_input.setText("");//开头不能输入乘除号
//                    break;
//                }

                if (((Button) v).getText().equals("+") || ((Button) v).getText().equals("-") || ((Button) v).getText().equals("×") || ((Button) v).getText().equals("÷")) {
                    //若输入为符号
                    pt_flag = true;//输入符号后，小数点标志符置true，表示此后可以输入小数点
                    if ((str.equals("") || str == null || ((str.length() == 1) && (str.startsWith("+") || str.startsWith("-"))))) {
                        //开头可以输入正负号，不可输入乘除号
                        if (((Button) v).getText().equals("+") || ((Button) v).getText().equals("-")) {
                            et_input.setText(((Button) v).getText());
                            break;
                        } else {
                            break;
                        }
                    } else if ((str.endsWith("+") || str.endsWith("-") || str.endsWith("×") || str.endsWith("÷"))) {
                        //后续连续输入符号则以最后输入符号为最终符号
                        str = str.substring(0, str.length() - 1);
                        et_input.setText(str + ((Button) v).getText());
                        break;
                    } else {
                        et_input.setText(str + ((Button) v).getText());
                        break;
                    }
                } else {
                    //若输入为数字 则正常输入
                    et_input.setText(str + ((Button) v).getText());
                    break;
                }

//                if (!str.equals("")) {
//                    if (str.length()==3&&str.startsWith(" ")) {
//                        if (((Button) v).getText().equals("+") || ((Button) v).getText().equals("-")){
//                            et_input.setText(" " + ((Button) v).getText() + " ");
//                        } else {
//                            et_input.setText(str);
//                        }
//                        break;
//                    }else if(str.length()==1&&str.startsWith("-")){
//                        if (((Button) v).getText().equals("+") || ((Button) v).getText().equals("-")){
//                            et_input.setText(" " + ((Button) v).getText() + " ");
//                        } else {
//                            et_input.setText(str);
//                        }
//                        break;
//                    }
//                    else if(str.length()>3){
//                        if (((Button) v).getText().equals("+") || ((Button) v).getText().equals("-")) {
//                            et_input.setText(" " + ((Button) v).getText() + " ");
//                            break;
//                        } else {
//                            et_input.setText(str);
//                            break;
//                        }
//                    }
//                }

            case R.id.btn_clr://清空，置空
                et_input.setText("");
                pt_flag = true;
                break;
            case R.id.btn_del://删除一位
                if (str != null && !str.equals("")) {
                    if (str.endsWith("."))
                        pt_flag = true;
                    if (str.endsWith(")")) {
                        //若为带括号数则删除整个括号部分
                        for (int i = str.length() - 1; i >= 0; i--) {
                            if (str.charAt(i) == '(') {
                                et_input.setText(str.substring(0, i));
                            }
                        }
                    } else
                        //其他情况则，直接截断
                        et_input.setText(str.substring(0, str.length() - 1));
                }
                break;
            case R.id.btn_eq: //单独运算最后结果
                getResult();//调用下面的方法
                if (et_input.getText().toString().equals("错误"))
                    er_flag = true;
                break;
            case R.id.btn_gh:
                if (et_input.getText().toString().equals("")) {
                    et_input.setText("错误");
                    er_flag = true;
                    break;
                }
                getResult();
                if (et_input.getText().toString().contains("错误")) {
                    et_input.setText("错误");
                    er_flag = true;
                    break;
                }
                String str_gh = et_input.getText().toString();
                if (str_gh.contains("-")) {
                    //若结果为负数，则开根号失败
                    et_input.setText("错误");
                    er_flag = true;
                    break;
                }
                double num = Double.parseDouble(str_gh);
                et_input.setText(Math.sqrt(num) + "");
                break;
            case R.id.btn_cg://变号
                String str_cg = et_input.getText().toString();
                if (str.endsWith("+") || str.endsWith("-") || str.endsWith("×") || str.endsWith("÷")) {
                    break;
                }
                int lo = 0;
                for (int i = 1; i < str_cg.length(); i++) {
                    if (str_cg.substring(0, i).endsWith("+") || str_cg.substring(0, i).endsWith("-") || str_cg.substring(0, i).endsWith("×") || str_cg.substring(0, i).endsWith("÷")) {
                        lo = i;//寻找到最后输入的符号，以便于后续变号
                    }
                }
                String last = str_cg.substring(lo);
                if (lo == 0) {
                    et_input.setText("-" + str_cg);
                } else {
                    et_input.setText(str_cg.substring(lo - 1, lo));
                    if (str_cg.substring(lo - 1, lo).equals("+")) {
                        if (str_cg.endsWith(")")) {
                            et_input.setText(str_cg.substring(0, lo - 2) + "-" + last.substring(0, last.length() - 1));
                        } else
                            et_input.setText(str_cg.substring(0, lo - 1) + "-" + last);
                    }
                    if (str_cg.substring(lo - 1, lo).equals("-")) {
                        if (str_cg.endsWith(")")) {
                            et_input.setText(str_cg.substring(0, lo - 2) + last.substring(0, last.length() - 1));
                        } else if (str_cg.startsWith("-")) {
                            et_input.setText(str_cg.substring(0, lo - 1) + last);
                        } else
                            et_input.setText(str_cg.substring(0, lo - 1) + "+" + last);
                    }
                    if (str_cg.substring(lo - 1, lo).equals("×")) {
                        et_input.setText(str_cg.substring(0, lo) + "(-" + last + ")");
                    }
                    if (str_cg.substring(lo - 1, lo).equals("÷")) {
                        et_input.setText(str_cg.substring(0, lo) + "(-" + last + ")");
                    }
                }
        }
    }

    private void getResult() {
        String str_d = et_input.getText().toString();
        if (str_d.equals("") || str_d == null) {
            et_input.setText("");
        } else if (str_d.contains("(-")) {
            //为”(-“补0于-前
            while (str_d.contains("(-")) {
                String oo = str_d.substring(str_d.indexOf("(-") + 1);
                System.out.println(str_d.indexOf("(-"));
                str_d = str_d.substring(0, str_d.indexOf("(-") + 1) + "0" + oo;
                System.out.println(str_d);
                et_input.setText(sq_1.calculate(str_d));
            }
        }
//        else if(!str_d.contains("(-")||!str_d.contains("(")) {
//            et_input.setText("错误");
//            er_flag = true;
//        }
        else {
            et_input.setText(sq_1.calculate(str_d));
        }
        String str_t = et_input.getText().toString();
        if (str_t.contains(".")) {
            pt_flag = false;
        } else {
            pt_flag = true;
        }
//        et_input.setText("错误" + "");
//
//        String s1 = null;
//        String op = null;
//        String s2 = null;
//        boolean s1_flag = true;
//
//        if (str_d == null || str_d.equals("")) return;
//        //因为没有运算符所以不用运算
//        if (!str_d.contains(" ")) {
//            return;
//        }
//        str_d = et_input.getText().toString() + " ";
//        //截取运算符前面的字符串
//        if (!str_d.startsWith(" ")) {
//            s1 = str_d.substring(0, str_d.indexOf(" "));
//        } else if (str_d.substring(0, 3).equals(" + ")) {
//            str_d = str_d.substring(3);
//            s1 = str_d.substring(0, str_d.indexOf(" "));
//        } else if (str_d.substring(0, 3).equals(" - ")) {
//            str_d = str_d.substring(3);
//            s1 = str_d.substring(0, str_d.indexOf(" "));
//            s1_flag = false;
//        }
//        //截取的运算符以及S2
//        str_d = str_d.substring(str_d.indexOf(" "));
//        if (str_d.equals(" ") || str_d.length() == 3) {// 若未输入运算符 || 输入运算符后未输入S2
//            op = "";
//            s2 = "";
//        } else {
//            op = str_d.substring(1, 2);
//            //截取运算符后面的字符串
//            str_d = str_d.substring(str_d.indexOf(" ") + 3);
//            s2 = str_d.substring(0, str_d.indexOf(" "));
//        }
//
//        double cnt = 0;
//        System.out.println("|s1|=" + s1 + ",s1是否为正数：" + s1_flag);
//        //如果s1不是空    s2不是空  就执行下一步
//        if (!s1.equals("") && !s2.equals("")) {
//            double d1 = Double.parseDouble(s1);
//            double d2 = Double.parseDouble(s2);
//            if (op.equals("+")) {
//                if (!s1_flag) {
//                    cnt = d2 - d1;
//                } else
//                    cnt = d1 + d2;
//            }
//            if (op.equals("-")) {
//                if (!s1_flag) {
//                    cnt = 0 - d1 - d2;
//                } else
//                    cnt = d1 - d2;
//            }
//            if (op.equals("×")) {
//                cnt = d1 * d2;
//                if (!s1_flag) {
//                    cnt = 0 - cnt;
//                }
//            }
//            if (op.equals("÷")) {
//                if (d2 == 0) {
//                    cnt = 0;
//                    er_flag = true;
//                } else cnt = d1 / d2;
//            }
//            if (er_flag) {
//                et_input.setText("错误" + "");
//            } else
//                et_input.setText(cnt + "");
//        }
//        //如果s1不是空    s2是空  就执行下一步
//        else if (!s1.equals("") && s2.equals("")) {
//            double d1 = Double.parseDouble(s1);
//            cnt = d1;
//            if (!s1_flag) {
//                cnt = 0 - cnt;
//            }
//            et_input.setText(cnt + "");
//        }
//        //如果s1是空
//        else if (s1.equals("")) {
//            et_input.setText("错误" + "");
//            er_flag = true;
//        }
    }
}
