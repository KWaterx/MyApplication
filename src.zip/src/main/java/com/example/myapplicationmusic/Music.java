package com.example.myapplicationmusic;

public class Music {
    public String name;
    public String player;
    public Music(){}
    public Music(String name,String player){
        this.name=name;
        this.player=player;
    }
    public Music(String name){
        this.name=name;
    }
}
