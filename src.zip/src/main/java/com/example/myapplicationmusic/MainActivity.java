package com.example.myapplicationmusic;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
    private List<Music> musicList = new ArrayList<>();
    String url;//音频本地地址
    String url0;
    int ID = 0;
    boolean flag = true;//音频是否加载成功的布尔值
    MediaPlayer mediaPlayer = new MediaPlayer();//API，播放存储在应用资源
    private boolean isSeekBarChanging;//互斥变量，防止进度条与定时器冲突。
    private int currentPosition;//当前音乐播放的进度
    private SeekBar seekBar;//进度条
    private Timer timer;//定时器

    //下载链接
    private List<String> downloadUrls = new ArrayList<String>() {{
        add("https://files.freemusicarchive.org/storage-freemusicarchive-org/tracks/NiWAOMdSP8Hj6H1IqKWh91dpxPfpQmAwE2QDwuKs.mp3?download=1&name=Audiobinger%20-%20Anne%20Frank.mp3");
        add("https://files.freemusicarchive.org/storage-freemusicarchive-org/tracks/YcKcasolCFrNfZVJtr5YaYZcS3eCv3waBC9XrTZx.mp3?download=1&name=Maarten%20Schellekens%20-%20The%20Little%20Match%20Girl%20%28ft.%20Enlia%29.mp3");
    }};


    private DownloadService.DownloadBinder downloadBinder;
    private ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceDisconnected(ComponentName name) {
        }
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Log.d("tag", "绑定服务调用了onServiceConnected方法");
            downloadBinder = (DownloadService.DownloadBinder) service;//为了要让DownloadService可以和活动进行通信
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);//加载布局
        initData();//初始化歌单


        MusicAdapter adapter = new MusicAdapter(MainActivity.this, R.layout.item, musicList);
        ListView listView = (ListView) findViewById(R.id.list_view);
        listView.setAdapter(adapter);//将适配器传递给listView


        TextView name = (TextView) findViewById(R.id.et_name);
        Button stopAndOn = (Button) findViewById(R.id.stop);
        Button next = (Button) findViewById(R.id.next);
        Button before = (Button) findViewById(R.id.before);


        seekBar = (SeekBar) findViewById(R.id.playSeekBar);   //监听滚动条事件
        seekBar.setOnSeekBarChangeListener(new MySeekBar());

        //list点击事件
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                Music music = musicList.get(position);
                ID = position;
                System.out.println(ID);
                name.setText(music.name);
//                url = music.url;
//                Toast.makeText(MainActivity.this, url, Toast.LENGTH_SHORT).show();
//                System.out.println("******");
//                System.out.println(url);
//                System.out.println("******");
                if (ContextCompat.checkSelfPermission(MainActivity.this,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(MainActivity.this,
                            new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                } else {
                    if (ID >= 6) {
                        String downloadUrl = downloadUrls.get(ID - 6);
                        url0 = getUrl(downloadUrl);
                        File file = new File(url0);
                        if (!file.exists()) {
                            //不存在则下载音乐
                            Toast.makeText(MainActivity.this, "准备下载", Toast.
                                    LENGTH_SHORT).show();
                            Toast.makeText(MainActivity.this, downloadUrl, Toast.
                                    LENGTH_LONG).show();
                            downloadBinder.startDownload(downloadUrl);
                            return;
                        }
                    }
                    initMediaPlayer();
                    if (flag)
                        stopAndOn.setText("||");
                }

            }
        });

        //暂停、播放
        stopAndOn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mediaPlayer.isPlaying()) {
                    currentPosition = mediaPlayer.getCurrentPosition();//记录播放的位置
                    mediaPlayer.pause(); // 暂停播放
                    stopAndOn.setText(">");
                    return;
                }
                if (!mediaPlayer.isPlaying()) {
                    mediaPlayer.start();//开始播放
                    stopAndOn.setText("| |");
                    timeOn();
                    return;
                }
            }
        });

        //下一曲
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ID + 1 <= musicList.size() - 1) {
                    Music music = musicList.get(ID + 1);
                    ID = ID + 1;
                    name.setText(music.name);
                    stopAndOn.setText("| |");
                    initMediaPlayer();
                } else {
                    Music music = musicList.get(0);
                    ID = 0;
                    name.setText(music.name);
                    stopAndOn.setText("| |");
                    initMediaPlayer();
                }
            }
        });

        //上一曲
        before.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ID - 1 >= 0) {
                    Music music = musicList.get(ID - 1);
                    ID = ID - 1;
                    name.setText(music.name);
                    stopAndOn.setText("| |");
                    initMediaPlayer();
                } else {
                    Music music = musicList.get(musicList.size() - 1);
                    ID = musicList.size() - 1;
                    name.setText(music.name);
                    stopAndOn.setText("| |");
                    initMediaPlayer();
                }
            }
        });

        Intent intent = new Intent(this, DownloadService.class);
        startService(intent); // 启动服务
        Log.d("tag", "服务启动");
        bindService(intent, connection, BIND_AUTO_CREATE); // 绑定服务
        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }

    }



    //播放初始化
    private void initMediaPlayer() {
        mediaPlayer.reset();
        try {
            if (ID >= 6) {
                //若为下载歌曲
                url = url0;
            } else{
                String directory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getPath();
                url = directory + '/' + musicList.get(ID).name + ".mp3";
            }
            System.out.println("-----------" + url);
            mediaPlayer.setDataSource(url);//设置要播放的音频文件的位置
            mediaPlayer.prepare();//完成开始播放之前的准备工作
            initSeeKBar();
            mediaPlayer.start();//开始播放
            timeOn();
        } catch (Exception e) {
            Toast.makeText(MainActivity.this, "未下载", Toast.LENGTH_SHORT).show();
            flag = false;//使仍然为暂停键
            e.printStackTrace();
        }


    }

    //截取地址
    private String getUrl(String downloadUrl) {
        String url = downloadUrl;
        String fileName = url.substring(url.lastIndexOf('/'));
        //获取系统目录
        String directory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getPath();
        return directory + fileName;
    }

    //初始化音乐列表
    private void initData() {
        musicList.add(new Music("Bears Conference", "Lobo Loco"));//测试
        musicList.add(new Music("Careless Whisper", "邓丽君"));//测试
        musicList.add(new Music("Die weisse Taube", "Lobo Loco"));//测试
        musicList.add(new Music("蔓珠莎华", "梅艳芳"));//测试
        musicList.add(new Music("つぐない", "邓丽君"));//测试
        musicList.add(new Music("人间の证明", "ジョー山中"));//测试
        musicList.add(new Music("Anne Frank"));//测试
        musicList.add(new Music("En lia"));//测试

    }

    //进度条处理
    public class MySeekBar implements SeekBar.OnSeekBarChangeListener {

        public void onProgressChanged(SeekBar seekBar, int progress,
                                      boolean fromUser) {
        }

        //滚动时,应当暂停后台定时器
        public void onStartTrackingTouch(SeekBar seekBar) {
            isSeekBarChanging = true;
        }

        //滑动结束后，重新设置值
        public void onStopTrackingTouch(SeekBar seekBar) {
            isSeekBarChanging = false;
            mediaPlayer.seekTo(seekBar.getProgress());
        }
    }

    //初始化进度条
    private void initSeeKBar() {
        seekBar.setMax(mediaPlayer.getDuration());//获取音频总时长
    }

    //开始计时
    public void timeOn() {
        seekBar.setMax(mediaPlayer.getDuration());
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                if (!isSeekBarChanging) {
                    seekBar.setProgress(mediaPlayer.getCurrentPosition());
                }
            }
        }, 0, 50);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case 1:
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    initMediaPlayer();
                } else {
                    Toast.makeText(this, "用户没有授予读取外部存储的权限", Toast.LENGTH_SHORT)
                            .show();
                    finish();
                }
                break;
        }
    }

    //释放资源
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
            timer.cancel();
            timer = null;

        }
    }
}